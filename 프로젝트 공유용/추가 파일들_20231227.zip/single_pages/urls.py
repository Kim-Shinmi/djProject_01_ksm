from django.urls import path
from . import views

urlpatterns = [
    path("", views.index),
    path("jobList", views.jobList),
    path("jobInterest", views.jobInterest),
    path("jobExperience", views.jobExperience),
]

