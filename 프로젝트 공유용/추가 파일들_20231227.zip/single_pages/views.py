from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, "index.html")

def jobList(request):
    return render(request, "subPage_jobList.html")

def jobInterest(request):
    return render(request, "subPage_jobInterest.html")

def jobExperience(request):
    return render(request, "subPage_jobExperience.html")